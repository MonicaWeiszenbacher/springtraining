package eu.accesa.springtraining.controller;

import eu.accesa.springtraining.data.address.AddressData;
import eu.accesa.springtraining.data.exception.AppException;
import eu.accesa.springtraining.data.exception.WebServiceException;
import eu.accesa.springtraining.model.Address;
import eu.accesa.springtraining.service.AddressService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Tag(name = "address", description = "REST API for CRUD operations on addresses")
@RestController
@RequestMapping("v1/addresses")
@ControllerAdvice
@Log4j2
public class AddressController {

    private final AddressService addressService;

    public AddressController(AddressService addressService) {
        this.addressService = addressService;
    }

    @Operation(summary = "Returns all addresses")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success")
    })
    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Address> getAddresses() {
        Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication()).map(Principal::getName)
                .ifPresent(user -> log.info("GET addresses requested by user {}", user));
                
        return addressService.getAddresses();
    }

    @Operation(summary = "Returns an address by id")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "404", description = "Address not found")
    })
    @GetMapping(path = "/{id}")
    public Address getAddress(
            @Parameter(description = "Address PK", required = true)
            @PathVariable Long id) {
        return addressService.getAddress(id);
    }

    @Operation(summary = "Creates an address")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "400", description = "Address request body is not valid")
    })
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public void saveAddress(
            @Parameter(description = "Contains the address fields")
            @RequestBody @Valid AddressData address, BindingResult bindingResult) {
        validateAddress(bindingResult);
        addressService.saveAddress(address);
    }

    @Operation(summary = "Updates an address")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "400", description = "Address request body is not valid"),
            @ApiResponse(responseCode = "404", description = "Address is not found")
    })
    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public void updateAddress(
            @Parameter(description = "Address PK")
            @PathVariable Long id,
            @Parameter(description = "Contains the address fields")
            @RequestBody @Valid AddressData address,
            BindingResult bindingResult) {
        validateAddress(bindingResult);
        addressService.updateAddress(id, address);
    }

    @Operation(summary = "Deletes an address")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Success"),
            @ApiResponse(responseCode = "404", description = "Address is not found")
    })
    @DeleteMapping("/{id}")
    void deleteAddress(@Parameter(description = "PK of an address", required = true)
                       @PathVariable Long id) {
        addressService.deleteAddress(id);
    }

    private void validateAddress(BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            Map<String, Object> errors = Map.of("errors", bindingResult.getAllErrors().stream()
                    .map(DefaultMessageSourceResolvable::getDefaultMessage).toList());
            throw new AppException(HttpStatus.BAD_REQUEST, "bad_request", errors);
        }
    }

    @ExceptionHandler
    public ResponseEntity<String> handleAddressWebServiceException(WebServiceException e) {
        log.error("Web service call to get address by id failed", e);
        return ResponseEntity.internalServerError().body("Web service error: " + e.getMessage());
    }

    @Operation(summary = "Imports an address from the FTP server")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "500", description = "Communication with FTP server failed")
    })
    @PostMapping(value = "import", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public void importAddress(@RequestParam String fileName) {
        addressService.importAddress(fileName);
    }
}