package eu.accesa.springtraining.data.exception;

import lombok.Getter;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collections;
import java.util.Map;

@Getter
public class AppException extends ResponseStatusException {
    
    private final Map<String, Object> messageArguments;

    public AppException(HttpStatusCode status, String errorKey) {
        super(status, errorKey);
        this.messageArguments = Collections.emptyMap();
    }

    public AppException(HttpStatusCode status, String errorKey, Map<String, Object> messageArguments) {
        super(status, errorKey);
        this.messageArguments = messageArguments;
    }
}
