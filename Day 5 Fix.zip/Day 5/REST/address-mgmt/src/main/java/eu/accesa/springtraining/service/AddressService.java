package eu.accesa.springtraining.service;

import eu.accesa.springtraining.data.address.AddressData;
import eu.accesa.springtraining.data.exception.AddressNotFoundException;
import eu.accesa.springtraining.model.Address;
import eu.accesa.springtraining.repository.AddressRepository;
import io.netty.resolver.DefaultAddressResolverGroup;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.integration.ftp.session.FtpRemoteFileTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.util.List;
import java.util.stream.StreamSupport;

@Service
public class AddressService {
    
    private final AddressRepository repository;
    private final WebClient webClient;
    private final FtpRemoteFileTemplate ftpRemoteFileTemplate;

    public AddressService(AddressRepository addressRepository, FtpRemoteFileTemplate ftpRemoteFileTemplate) {
        this.repository = addressRepository;
        this.webClient = WebClient.builder().baseUrl("http://localhost:8090")
                .clientConnector(new ReactorClientHttpConnector(HttpClient.create().resolver(DefaultAddressResolverGroup.INSTANCE)))
                .build();
        this.ftpRemoteFileTemplate = ftpRemoteFileTemplate;
    }
    
    public List<Address> getAddresses() {
        return StreamSupport.stream(repository.findAll().spliterator(), false).toList();
    }

    public Address getAddress(long id) {
        return webClient.method(HttpMethod.GET).uri("/address/" + id)
                .contentType(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(Address.class)
                .blockOptional()
                .orElseThrow(AddressNotFoundException::new);
    }
    
    public void saveAddress(AddressData address) {
        Address newAddress = new Address();
        
        newAddress.setStreet(address.getStreet());
        newAddress.setPostalCode(address.getPostalCode());
        newAddress.setCountryCode(address.getCountryCode());
        
        repository.save(newAddress);
    }

    public void updateAddress(long id, AddressData updatedAddress) {
        Address address = repository.findById(id).orElseThrow(AddressNotFoundException::new);
        address.setStreet(updatedAddress.getStreet());
        address.setPostalCode(updatedAddress.getPostalCode());
        
        repository.save(address);
    }
    
    public void deleteAddress(long id) {
        Address address = repository.findById(id).orElseThrow(AddressNotFoundException::new);
        
        repository.deleteById(address.getId());
    }
    
    public void importAddress(String fileName) {
        ftpRemoteFileTemplate.get("springtraining/" + fileName, stream -> {
            Address address = new Address();
            String[] content = new String(stream.readAllBytes()).split(",");
            address.setStreet(content[0]);
            address.setPostalCode(content[1]);
            address.setCountryCode(content[2]);
            repository.save(address);
        });
    }
}
