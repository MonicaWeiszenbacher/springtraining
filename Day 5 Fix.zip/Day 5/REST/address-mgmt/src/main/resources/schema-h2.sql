CREATE SCHEMA IF NOT EXISTS training;

CREATE TABLE IF NOT EXISTS training.address
(
    id             bigint  NOT NULL,
    street         text,
    postal_code text,
    country_code text,
    created_by text,
    modified_by text,
    CONSTRAINT address_pkey PRIMARY KEY (id)
    );
CREATE SEQUENCE IF NOT EXISTS training.address_seq START WITH 1;
CREATE INDEX IF NOT EXISTS training_address_postal_code_idx on training.address(id);

CREATE TABLE IF NOT EXISTS training.app_user
(
    id        bigint  NOT NULL,
    email     text,
    password  text,
    user_role text,
    CONSTRAINT user_pkey PRIMARY KEY (id)
    );
CREATE SEQUENCE IF NOT EXISTS training.app_user_seq START WITH 1;