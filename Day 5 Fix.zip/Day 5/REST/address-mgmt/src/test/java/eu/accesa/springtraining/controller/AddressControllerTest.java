package eu.accesa.springtraining.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import eu.accesa.springtraining.data.address.AddressData;
import eu.accesa.springtraining.data.exception.AddressNotFoundException;
import eu.accesa.springtraining.data.exception.WebServiceException;
import eu.accesa.springtraining.model.Address;
import eu.accesa.springtraining.service.AddressService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(AddressController.class)
class AddressControllerTest {
    
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AddressService service;

    @Mock
    private Address address;

    @Test
    @DisplayName("Should get all addresses")
    void testGetAddresses() throws Exception {
        List<Address> addresses = List.of(getAddress());

        when(service.getAddresses()).thenReturn(addresses);

        mockMvc.perform(get("/v1/addresses")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(address)))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().string(OBJECT_MAPPER.writeValueAsString(addresses)));

        verify(service).getAddresses();
    }

    @Test
    @DisplayName("Should throw Not Found exception")
    void testGetAddress1() throws Exception {
        when(service.getAddress(2L)).thenThrow(AddressNotFoundException.class);

        mockMvc.perform(get("/v1/addresses/2")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

        verify(service).getAddress(2L);
    }

    @Test
    @DisplayName("Should throw web service exception")
    void testGetAddress2() throws Exception {
        when(service.getAddress(2L)).thenThrow(new WebServiceException("Server is down"));

        mockMvc.perform(get("/v1/addresses/2")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isInternalServerError())
                .andExpect(content().string(containsString("Web service error: Server is down")));

        verify(service).getAddress(2L);
    }

    @Test
    @DisplayName("Should save address")
    void testSaveAddress1() throws Exception {
        AddressData addressData = getAddressData();
        
        mockMvc.perform(post("/v1/addresses")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(OBJECT_MAPPER.writeValueAsString(addressData)))
                .andExpect(status().isCreated());

        verify(service).saveAddress(addressData);
    }

    @Test
    @DisplayName("Should throw Bad Request exception for invalid address request body")
    void testSaveAddress2() throws Exception {
        mockMvc.perform(post("/v1/addresses")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(OBJECT_MAPPER.writeValueAsString(new AddressData(null, "12", "12345abc"))))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(containsString("Street should not be null")))
                .andExpect(content().string(containsString("Postal code min length is 3")))
                .andExpect(content().string(containsString("Country code max length is 3")));

        verify(service, never()).saveAddress(any());
    }

    @Test
    @DisplayName("Should update address")
    void testUpdateAddress1() throws Exception {
        AddressData addressData = getAddressData();

        mockMvc.perform(put("/v1/addresses/3")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(OBJECT_MAPPER.writeValueAsString(addressData)))
                .andExpect(status().isOk());

        verify(service).updateAddress(3L, addressData);
    }

    @Test
    @DisplayName("Should reject XML request body")
    void testUpdateAddress2() throws Exception {
        mockMvc.perform(put("/v1/addresses/3")
                        .contentType(MediaType.APPLICATION_XML)
                        .content(OBJECT_MAPPER.writeValueAsString("<address></address>")))
                .andExpect(status().isUnsupportedMediaType());
    }

    @Test
    @DisplayName("Should delete address")
    void testDeleteAddress() throws Exception {
        mockMvc.perform(delete("/v1/addresses/1"))
                .andExpect(status().isOk());

        verify(service).deleteAddress(1);
    }
    
    private Address getAddress() {
        return new Address(1L, "street", "postal code", "DE", "user", "user");
    }
    
    private AddressData getAddressData() {
        return new AddressData("street", "postal code", "DE");
    }
}
