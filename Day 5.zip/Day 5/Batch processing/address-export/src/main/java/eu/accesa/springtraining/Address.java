package eu.accesa.springtraining;

import lombok.Data;

@Data
public class Address {
    
    private String street;
    private String postalCode;
    private String countryCode;
}