package eu.accesa.springtraining.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;

@Entity
@Table(name = "address", schema = "training")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@EntityListeners(AuditingEntityListener.class)
public class Address implements Serializable {

    @Schema(description = "Internal ID of the address", example = "123", requiredMode = Schema.RequiredMode.REQUIRED)
    @Id
    @SequenceGenerator(name = "address_seq", sequenceName = "training.address_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "address_seq")
    private Long id;
    
    @Schema(description = "Street and number")
    private String street;

    @Schema(description = "Numeric postal code")
    private String postalCode;

    @Schema(description = "ISO country code")
    private String countryCode;

    @Column(name = "created_by")
    @CreatedBy
    private String createdBy;

    @Column(name = "modified_by")
    @LastModifiedBy
    private String modifiedBy;
}
