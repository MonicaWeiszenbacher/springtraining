package eu.accesa.springtraining.data.security;

public record UserResponse(String language, String country, boolean isAdmin) {}
