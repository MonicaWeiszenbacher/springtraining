package eu.accesa.springtraining.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import eu.accesa.springtraining.data.exception.AppException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class GlobalExceptionService extends DefaultErrorAttributes {

    // key = language, value = JSON file content as key / value pairs
    private final Map<String, Map<String, String>> translations = new HashMap<>();
    
    @SuppressWarnings("unchecked")
    public GlobalExceptionService() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        translations.put("en", objectMapper.readValue(new ClassPathResource("translations/en.json").getInputStream(), Map.class));
        translations.put("de", objectMapper.readValue(new ClassPathResource("translations/de.json").getInputStream(), Map.class));
    }
    
    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        if (!(ex instanceof AppException errorResponse)) {
            return null;
        }
        
        response.setStatus(errorResponse.getStatusCode().value());
        
        Map<String, Object> errorMessage = new LinkedHashMap<>();
        String errorMessageKey = errorResponse.getBody().getDetail();
        String userLanguage = request.getLocale().getLanguage();
        String translatedErrorMessage = translations.getOrDefault(userLanguage, translations.get("en")).get(errorMessageKey);
        
        if (errorResponse.getMessageArguments() != null) {
            for (Map.Entry<String, Object> entry : errorResponse.getMessageArguments().entrySet()) {
                translatedErrorMessage = translatedErrorMessage.replace("{" + entry.getKey() + "}", entry.getValue().toString());
            }
        }
        
        errorMessage.put("status", errorResponse.getStatusCode().value());
        errorMessage.put("translatedErrorMessage", translatedErrorMessage);
      
        return new ModelAndView(new MappingJackson2JsonView(), errorMessage);
    }
}