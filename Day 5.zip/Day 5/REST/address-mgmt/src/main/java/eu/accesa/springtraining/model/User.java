package eu.accesa.springtraining.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;

@Entity
@Table(name = "app_user", schema = "training")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class User implements Serializable {

    @Schema(description = "Internal ID of the user", example = "123", requiredMode = Schema.RequiredMode.REQUIRED)
    @Id
    @SequenceGenerator(name = "app_user_seq", sequenceName = "training.user_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_seq")
    private Long id;
    
    @Schema(description = "Email address")
    private String email;

    @Schema(description = "Encoded password")
    private String password;

    @Schema(description = "User role")
    private String userRole;
}
