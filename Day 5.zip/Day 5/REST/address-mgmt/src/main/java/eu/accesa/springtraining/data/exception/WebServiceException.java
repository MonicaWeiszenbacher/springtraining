package eu.accesa.springtraining.data.exception;

public class WebServiceException extends RuntimeException {

    public WebServiceException(String message) {
        super(message);
    }
}