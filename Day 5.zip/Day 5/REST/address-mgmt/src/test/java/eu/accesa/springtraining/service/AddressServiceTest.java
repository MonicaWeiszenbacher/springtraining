package eu.accesa.springtraining.service;

public class AddressServiceTest {
    
}
