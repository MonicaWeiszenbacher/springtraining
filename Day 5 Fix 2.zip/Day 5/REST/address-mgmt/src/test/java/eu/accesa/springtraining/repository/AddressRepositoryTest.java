package eu.accesa.springtraining.repository;

import eu.accesa.springtraining.model.Address;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.ContextConfiguration;

import java.util.List;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ContextConfiguration(classes = AddressRepository.class)
@DataJpaTest(showSql = false)
@EnableJpaRepositories(basePackageClasses = AddressRepository.class)
@EntityScan(basePackageClasses = Address.class)
class AddressRepositoryTest {

    @Autowired
    private TestEntityManager testEntityManager;

    @Autowired
    private AddressRepository addressRepository;

    @Test
    @DisplayName("Should return addresses by postal code")
    void testFindAllByPostalCodeIsIn() {
        IntStream.rangeClosed(1, 11).forEach(i -> {
            Address address = new Address();
            address.setPostalCode("123");
            testEntityManager.persist(address);
        });
        testEntityManager.flush();

        Page<Address> page = addressRepository.findAllByPostalCodeIsIn(List.of("123", "456"),
                PageRequest.of(0, 5, Sort.by(Sort.Direction.DESC, "id")));

        assertEquals(11, page.getTotalElements());
        assertEquals(3, page.getTotalPages());
        assertEquals(5, page.get().toList().size());
    }

    @Test
    @DisplayName("Should delete address")
    void testDelete() {
        testEntityManager.persistAndFlush(new Address());

        assertEquals(1, addressRepository.count());

        addressRepository.deleteAll();

        assertEquals(0, addressRepository.count());
    }

    @Test
    @DisplayName("Should save address")
    void testSave() {
        addressRepository.save(new Address());

        assertEquals(1, addressRepository.count());
    }
}
