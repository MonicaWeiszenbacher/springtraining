package eu.accesa.springtraining.repository;


import eu.accesa.springtraining.model.Address;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface AddressRepository extends CrudRepository<Address, Long> {
    
    @Transactional(readOnly = true)
    Page<Address> findAllByPostalCodeIsIn(List<String> postalCodes, Pageable pageable);
}