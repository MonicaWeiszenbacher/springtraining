package eu.accesa.springtraining.data.address;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AddressData {
    
    @Schema(description = "Street name", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotNull(message = "Street should not be null")
    private String street;

    @Schema(description = "Postal code", requiredMode = Schema.RequiredMode.REQUIRED)
    @Size(min = 3, message = "Postal code min length is 3")
    private String postalCode;

    @Schema(description = "ISO country code", requiredMode = Schema.RequiredMode.REQUIRED)
    @Size(max = 3, message = "Country code max length is 3")
    private String countryCode;
}