package eu.accesa.springtraining.configuration;

import eu.accesa.springtraining.model.Address;
import eu.accesa.springtraining.model.User;
import eu.accesa.springtraining.repository.AddressRepository;
import eu.accesa.springtraining.repository.UserRepository;
import jakarta.annotation.PostConstruct;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;

import java.util.List;
import java.util.stream.IntStream;

@Configuration
@ConditionalOnProperty(name = "spring.sql.init.platform", havingValue = "h2")
@DependsOn("addressAuditConfiguration")
public class SampleDataConfiguration {

    private final AddressRepository addressRepository;
    private final UserRepository userRepository;

    public SampleDataConfiguration(AddressRepository addressRepository,
                                   UserRepository userRepository) {
        this.addressRepository = addressRepository;
        this.userRepository = userRepository;
    }

    @PostConstruct
    void setUp() {
        List<Address> addresses = IntStream.rangeClosed(1, 100)
                .mapToObj(i -> {
                    Address address = new Address();
                    address.setPostalCode(RandomStringUtils.randomNumeric(5));
                    address.setStreet(RandomStringUtils.randomAlphanumeric(10));
                    address.setCountryCode(RandomStringUtils.randomAlphanumeric(2));
                    return address;
                }).toList();

        addressRepository.saveAll(addresses);
        
        User user = new User();
        user.setEmail("test@test.com");
        user.setPassword("{bcrypt}$2a$10$dXJ3SW6G7P50lGmMkkmwe.20cQQubK3.HZWzG3YB1tlRy.fqvM/BG"); // unencoded = "password"
        user.setUserRole("USER");
       
        userRepository.save(user);
    }
}
