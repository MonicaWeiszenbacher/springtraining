package eu.accesa.springtraining;

import lombok.extern.log4j.Log4j2;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Component
@Log4j2
public class JobCompletionNotificationListener implements JobExecutionListener {
	
	private final String fileName;

	public JobCompletionNotificationListener(@Value("${result.file.location}") String fileName) {
		this.fileName = fileName;
	}

	@Override
	public void beforeJob(JobExecution jobExecution) {
		JobExecutionListener.super.beforeJob(jobExecution);
		
		try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(fileName))) {
			writer.write("");
			writer.flush();
		} catch (IOException e) {
			log.error("Error clearing up result file", e);
		}
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			log.info("JOB FINISHED! Time to verify the results");
		}
	}
}
