package eu.accesa.springtraining;

import lombok.extern.log4j.Log4j2;
import org.springframework.batch.core.ItemReadListener;

@Log4j2
public class AddressReadListener implements ItemReadListener<Address> {

    @Override
    public void afterRead(Address item) {
        ItemReadListener.super.afterRead(item);
        log.info(item.toString());
    }

    @Override
    public void onReadError(Exception ex) {
        ItemReadListener.super.onReadError(ex);
        log.warn("Item could not be read", ex);
    }
}
