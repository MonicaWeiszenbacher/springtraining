package eu.accesa.springtraining;

import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.builder.JdbcPagingItemReaderBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.PathResource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.util.Collections;

@Configuration
public class BatchConfiguration {

    private static final int CHUNK_SIZE = 5;

    @Bean
    public FlatFileItemReader<Address> fileReader() {
        return new FlatFileItemReaderBuilder<Address>()
                .name("fileItemReader")
                .resource(new ClassPathResource("sample-data.csv"))
                .delimited()
                .names("street", "postalCode", "countryCode")
                .targetType(Address.class)
                .build();
    }

    @Bean
    public JdbcPagingItemReader<Address> databaseReader(DataSource dataSource) {
        return new JdbcPagingItemReaderBuilder<Address>()
                .name("databaseItemReader")
                .dataSource(dataSource)
                .selectClause("SELECT * ")
                .fromClause("FROM training.address ")
                .pageSize(CHUNK_SIZE)
                .sortKeys(Collections.singletonMap("id", Order.ASCENDING))
                .beanRowMapper(Address.class)
                .build();
    }

    @Bean
    public FlatFileItemWriter<Address> writer(@Value("${result.file.location}") String fileName) {
        FlatFileItemWriter<Address> writer = new FlatFileItemWriter<>();
        writer.setResource(new PathResource(fileName));
        writer.setAppendAllowed(true);
        writer.setLineAggregator(item -> String.join(",", quoteEscape(item.getStreet()), quoteEscape(item.getPostalCode()),
                quoteEscape(item.getCountryCode())));
        return writer;
    }
    
    @Bean
    public ItemReadListener<Address> itemReadListener() {
        return new AddressReadListener();
    }

    @Bean
    public Job exportAddressJob(JobRepository jobRepository, Step step1, Step step2, JobCompletionNotificationListener listener) {
        return new JobBuilder("exportAddressJob", jobRepository)
                .listener(listener)
                .start(step1)
                .next(step2)
                .build();
    }

    @Bean
    public Step step1(JobRepository jobRepository, DataSourceTransactionManager transactionManager,
                      FlatFileItemReader<Address> reader, FlatFileItemWriter<Address> writer) {
        return new StepBuilder("step1", jobRepository)
                .<Address, Address>chunk(CHUNK_SIZE, transactionManager)
                .reader(reader)
                .writer(writer)
                .listener(itemReadListener())
                .build();
    }

    @Bean
    public Step step2(JobRepository jobRepository, DataSourceTransactionManager transactionManager,
                      JdbcPagingItemReader<Address> reader, FlatFileItemWriter<Address> writer) {
        return new StepBuilder("step2", jobRepository)
                .<Address, Address>chunk(CHUNK_SIZE, transactionManager)
                .reader(reader)
                .writer(writer)
                .listener(itemReadListener())
                .build();
    }
	
	private String quoteEscape(String value) {
		return "\"" + value + "\"";
	}
}